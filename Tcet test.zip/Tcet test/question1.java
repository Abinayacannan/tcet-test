package com.tcet;


	interface Sayable{
		String say(String name);
	}
	public class question1{
		public static void main(String args[])
		{
			Sayable s1=name->"Hello"+name+"!";
			String greeting=s1.say("World");
			System.out.println(greeting);
		}

}
