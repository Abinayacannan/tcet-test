package com.tcet;
import java.util.*;
public class question5 {

	public static void main(String[] args) {
		        Scanner scanner = new Scanner(System.in);
		        System.out.println("Enter the number of crates:");
		        int n = scanner.nextInt();
		        int[] crates = new int[n];
		        System.out.println("Enter the crate values:");
		        for (int i = 0; i < n; i++) {
		            crates[i] = scanner.nextInt();
		        }
		        scanner.close();
		        System.out.println("Original array:");
		        printArray(crates);
		        moveEmptyCratesToEnd(crates);
		        System.out.println("Array after moving empty crates to the end:");
		        printArray(crates);
		    }
		    public static void moveEmptyCratesToEnd(int[] array) {
		        int lastNonZeroIndex = 0;
		        for (int i = 0; i < array.length; i++) {
		            if (array[i] != 0) {
		                int temp = array[lastNonZeroIndex];
		                array[lastNonZeroIndex] = array[i];
		                array[i] = temp;
		                lastNonZeroIndex++;
		            }
		        }
		    }
		    public static void printArray(int[] array) {
		        for (int value : array) {
		            System.out.print(value + " ");
		        }
		        System.out.println();
		    }
		}  
