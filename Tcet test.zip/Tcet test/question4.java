package com.tcet;
	import java.util.ArrayList;
	import java.util.List;
	import java.util.Scanner;
	import java.util.stream.Collectors;

	public class question4{
	    public static void main(String[] args) {
	        
	        Scanner sc = new Scanner(System.in);
	        int size = sc.nextInt();
	        List<Integer> numbers = new ArrayList<>();
            System.out.println("Enter the integers:");
	        for (int i = 0; i < size; i++) {
	            numbers.add(sc.nextInt());
	        }
	        List<Integer> evenNumbers = numbers.stream()
	                                           .filter(n -> n % 2 == 0)
	                                           .collect(Collectors.toList());

	        
	        System.out.println("Even Numbers: " + evenNumbers);

	        
	        sc.close();
	    }
	}
