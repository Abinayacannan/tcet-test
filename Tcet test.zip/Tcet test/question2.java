package com.tcet;
class demo implements Runnable {
			    public void run() {
			        for (int i = 1; i <= 5; i++) {
			            System.out.println(i);
			            try {
			                Thread.sleep(1000); 
			            } catch (Exception e) {
			                e.printStackTrace();
			            }
			        }
			    }
			}

			public class question2{
			    public static void main(String[] args) {
			        demo n = new demo();
			        Thread thread = new Thread(n);
			        thread.start();
			    }
			}